from django.contrib import admin
from .models import *
@admin.register(Investor)
class InvestorAdmin(admin.ModelAdmin): list_display=('code','name','phone');search_fields=('code','name')
@admin.register(Plot)
class PlotAdmin(admin.ModelAdmin):list_display=('number','area','activity','status');list_filter=('status',);search_fields=('number',)
@admin.register(InvestorContract)
class InvestorContractAdmin(admin.ModelAdmin):list_display=('number','investor','plot','signed_on','status');list_filter=('status',)
@admin.register(Receipt)
class ReceiptAdmin(admin.ModelAdmin):list_display=('number','contract','amount','received_on')
@admin.register(Installment)
class InstallmentAdmin(admin.ModelAdmin):list_display=('contract','due_on','amount')
@admin.register(Contractor)
class ContractorAdmin(admin.ModelAdmin):list_display=('name','phone')
@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):list_display=('code','name','budget','progress')
@admin.register(ContractorContract)
class ContractorContractAdmin(admin.ModelAdmin):list_display=('number','contractor','project','value')
@admin.register(PaymentCertificate)
class PaymentCertificateAdmin(admin.ModelAdmin):list_display=('number','contract','gross','deductions','status')
@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):list_display=('description','project','amount','status');list_filter=('status',)
@admin.register(AuditEvent)
class AuditAdmin(admin.ModelAdmin):list_display=('timestamp','actor','action','entity','entity_id');readonly_fields=('actor','action','entity','entity_id','timestamp','details')
 def has_add_permission(self,request):return False
 def has_change_permission(self,request,obj=None):return False
 def has_delete_permission(self,request,obj=None):return False
