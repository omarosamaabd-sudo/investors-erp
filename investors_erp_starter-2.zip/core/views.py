import csv
from decimal import Decimal
from django.contrib.auth.decorators import login_required,permission_required
from django.db.models import Sum
from django.http import HttpResponse
from django.shortcuts import render
from .models import Investor,Plot,InvestorContract,Receipt,ContractorContract,Project,Expense,PaymentCertificate
@login_required
def dashboard(request):
 context={'investor_count':Investor.objects.count(),'plot_count':Plot.objects.count(),'project_count':Project.objects.count(),'receipts_total':Receipt.objects.aggregate(s=Sum('amount'))['s'] or Decimal(0),'projects':Project.objects.all()[:8]}
 return render(request,'core/dashboard.html',context)
@login_required
@permission_required('core.view_investor',raise_exception=True)
def investors(request):return render(request,'core/list.html',{'title':'المستثمرون','headers':['الكود','الاسم','الهاتف'],'rows':[(x.code,x.name,x.phone) for x in Investor.objects.all()[:200]],'model':'investor'})
@login_required
@permission_required('core.view_plot',raise_exception=True)
def plots(request):return render(request,'core/list.html',{'title':'قطع الأراضي','headers':['القطعة','المساحة م²','النشاط','الحالة'],'rows':[(x.number,x.area,x.activity,x.get_status_display()) for x in Plot.objects.all()[:200]],'model':'plot'})
@login_required
@permission_required('core.view_contractorcontract',raise_exception=True)
def contractors(request):return render(request,'core/list.html',{'title':'عقود المقاولات','headers':['العقد','المقاول','المشروع','القيمة'],'rows':[(x.number,x.contractor.name,x.project.name,x.value) for x in ContractorContract.objects.select_related('contractor','project')[:200]],'model':'contractorcontract'})
@login_required
@permission_required('core.view_expense',raise_exception=True)
def finance(request):return render(request,'core/list.html',{'title':'المصروفات','headers':['البيان','المشروع','المبلغ','الحالة'],'rows':[(x.description,x.project.name if x.project else 'عام',x.amount,x.get_status_display()) for x in Expense.objects.select_related('project')[:200]],'model':'expense'})
@login_required
@permission_required('core.view_receipt',raise_exception=True)
def reports(request):
 response=HttpResponse(content_type='text/csv; charset=utf-8');response['Content-Disposition']='attachment; filename="receipts.csv"';response.write('\ufeff')
 writer=csv.writer(response);writer.writerow(['رقم الإيصال','رقم العقد','التاريخ','المبلغ'])
 for x in Receipt.objects.select_related('contract').iterator():writer.writerow([x.number,x.contract.number,x.received_on,x.amount])
 return response
