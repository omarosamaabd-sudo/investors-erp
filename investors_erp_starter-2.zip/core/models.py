from django.db import models
from django.core.validators import MinValueValidator
from django.conf import settings
from decimal import Decimal
class Tracked(models.Model):
 created_at=models.DateTimeField(auto_now_add=True)
 updated_at=models.DateTimeField(auto_now=True)
 class Meta: abstract=True
class Investor(Tracked):
 code=models.CharField('كود المستثمر',max_length=30,unique=True)
 name=models.CharField('اسم المستثمر',max_length=220)
 registration_no=models.CharField('السجل التجاري',max_length=80,blank=True)
 phone=models.CharField('الهاتف',max_length=40,blank=True)
 email=models.EmailField('البريد الإلكتروني',blank=True)
 def __str__(self): return f'{self.code} - {self.name}'
 class Meta: verbose_name='مستثمر';verbose_name_plural='المستثمرون'
class Plot(Tracked):
 number=models.CharField('رقم القطعة',max_length=50,unique=True)
 area=models.DecimalField('المساحة م²',max_digits=14,decimal_places=2,validators=[MinValueValidator(Decimal('0.01'))])
 activity=models.CharField('النشاط',max_length=100,blank=True)
 status=models.CharField('الحالة',max_length=20,choices=[('available','متاحة'),('reserved','محجوزة'),('contracted','متعاقد عليها')],default='available')
 def __str__(self):return self.number
 class Meta: verbose_name='قطعة أرض';verbose_name_plural='قطع الأراضي'
class InvestorContract(Tracked):
 number=models.CharField('رقم العقد',max_length=60,unique=True)
 investor=models.ForeignKey(Investor,on_delete=models.PROTECT,related_name='contracts')
 plot=models.OneToOneField(Plot,on_delete=models.PROTECT,related_name='investor_contract')
 signed_on=models.DateField('تاريخ التعاقد')
 price_per_m2=models.DecimalField('سعر المتر',max_digits=14,decimal_places=2,validators=[MinValueValidator(Decimal('0.01'))])
 status=models.CharField('حالة العقد',max_length=20,choices=[('draft','مسودة'),('active','ساري'),('closed','منتهٍ')],default='draft')
 @property
 def total(self):return self.plot.area*self.price_per_m2
 def __str__(self):return self.number
 class Meta: verbose_name='عقد مستثمر';verbose_name_plural='عقود المستثمرين'
class Installment(Tracked):
 contract=models.ForeignKey(InvestorContract,on_delete=models.PROTECT,related_name='installments')
 due_on=models.DateField('تاريخ الاستحقاق')
 amount=models.DecimalField('القيمة',max_digits=16,decimal_places=2,validators=[MinValueValidator(Decimal('0.01'))])
 class Meta: verbose_name='قسط';verbose_name_plural='الأقساط'
class Receipt(Tracked):
 contract=models.ForeignKey(InvestorContract,on_delete=models.PROTECT,related_name='receipts')
 number=models.CharField('رقم الإيصال',max_length=60,unique=True)
 received_on=models.DateField('تاريخ التحصيل')
 amount=models.DecimalField('المبلغ',max_digits=16,decimal_places=2,validators=[MinValueValidator(Decimal('0.01'))])
 reference=models.CharField('مرجع التحويل',max_length=100,blank=True)
 class Meta: verbose_name='تحصيل';verbose_name_plural='التحصيلات'
class Contractor(Tracked):
 name=models.CharField('اسم المقاول',max_length=220)
 tax_no=models.CharField('الرقم الضريبي',max_length=80,blank=True)
 phone=models.CharField('الهاتف',max_length=40,blank=True)
 def __str__(self):return self.name
 class Meta: verbose_name='مقاول';verbose_name_plural='المقاولون'
class Project(Tracked):
 code=models.CharField('كود المشروع',max_length=50,unique=True)
 name=models.CharField('اسم المشروع',max_length=220)
 budget=models.DecimalField('الموازنة',max_digits=18,decimal_places=2,default=0)
 progress=models.PositiveSmallIntegerField('نسبة الإنجاز',default=0,validators=[MinValueValidator(0)])
 def __str__(self):return self.name
 class Meta: verbose_name='مشروع';verbose_name_plural='المشروعات'
class ContractorContract(Tracked):
 number=models.CharField('رقم العقد',max_length=60,unique=True)
 contractor=models.ForeignKey(Contractor,on_delete=models.PROTECT)
 project=models.ForeignKey(Project,on_delete=models.PROTECT)
 value=models.DecimalField('قيمة العقد',max_digits=18,decimal_places=2,validators=[MinValueValidator(Decimal('0.01'))])
 signed_on=models.DateField('تاريخ العقد')
 class Meta: verbose_name='عقد مقاولة';verbose_name_plural='عقود المقاولات'
class PaymentCertificate(Tracked):
 contract=models.ForeignKey(ContractorContract,on_delete=models.PROTECT)
 number=models.CharField('رقم المستخلص',max_length=60,unique=True)
 gross=models.DecimalField('إجمالي الأعمال',max_digits=18,decimal_places=2)
 deductions=models.DecimalField('الخصومات',max_digits=18,decimal_places=2,default=0)
 status=models.CharField('حالة الاعتماد',max_length=20,choices=[('draft','مسودة'),('technical','مراجعة فنية'),('financial','مراجعة مالية'),('approved','معتمد')],default='draft')
 class Meta: verbose_name='مستخلص';verbose_name_plural='المستخلصات'
class Expense(Tracked):
 description=models.CharField('البيان',max_length=300)
 project=models.ForeignKey(Project,on_delete=models.PROTECT,null=True,blank=True)
 amount=models.DecimalField('المبلغ',max_digits=18,decimal_places=2,validators=[MinValueValidator(Decimal('0.01'))])
 incurred_on=models.DateField('التاريخ')
 status=models.CharField('الحالة',max_length=20,choices=[('draft','مسودة'),('review','قيد المراجعة'),('approved','معتمد'),('paid','مدفوع')],default='draft')
 class Meta: verbose_name='مصروف';verbose_name_plural='المصروفات'
class AuditEvent(models.Model):
 actor=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.SET_NULL,null=True)
 action=models.CharField(max_length=60)
 entity=models.CharField(max_length=80)
 entity_id=models.CharField(max_length=80)
 timestamp=models.DateTimeField(auto_now_add=True)
 details=models.JSONField(default=dict,blank=True)
 class Meta: verbose_name='سجل مراجعة';verbose_name_plural='سجل المراجعة'
